document.body.style.backgroundColor="#222";
$("[href='https://vip.huijujiavip.com:8443?f=www.agefans.net']").parent().remove();
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse)
{
    if(request.code==1)
	window.open(decodeURIComponent(age_playfram.src.substring(
        age_playfram.src.indexOf("url=")+
        4,age_playfram.src.indexOf("&"))));
	sendResponse('success');
});